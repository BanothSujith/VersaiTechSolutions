const items =[
    {
        name:'idli  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
        pic:'./img/idli.png',
        price:40,
        rating:3.4,
        description:'some some  some some some some some  some some some some some some some some  some some some some some some some some  some some some some some some some some  some some some some some some some some some  '
    },

    {
        name:'vada' ,
        pic:'./img/vada.png',
        price:40,
        rating:3.4,
        description:'some some some some some content....'
    },
    {
        name:'paratha' ,
        pic:'./img/paratha.png',
        price:40,
        rating:3.4,
        description:'some some some some some content....'
    },
    {
        name:'idli',
        pic:'./img/idli.png',
        price:40,
        rating:3.4,
        description:'some some some some some some some some some content....'
    },

    {
        name:'vada' ,
        pic:'./img/image.png',
        price:40,
        rating:3.4,
        description:'some some some some some content....'
    },
    {
        name:'paratha' ,
        pic:'./img/paratha.png',
        price:40,
        rating:3.4,
        description:'some some some some some content....'
    },
    {
        name:'idli',
        pic:'./img/idli.png',
        price:40,
        rating:3.4,
        description:'some some some some some content....'
    },

    {
        name:'vada' ,
        pic:'./img/vada.png',
        price:40,
        rating:3.4,
        description:'some some some some some content....'
    },
    {
        name:'paratha' ,
        price:40,
        rating:3.4,
        pic:'./img/paratha.png',
        description:'some some some some some content....'
    },
    {
        name:'paratha' ,
        price:40,
        rating:3.4,
        pic:'./img/paratha.png',
        description:'some some some some some content....'
    },
    {
        name:'idli',
        pic:'./img/idli.png',
        price:4097978987,
        rating:3.4,
        description:'some some some some some content....'
    },

    {
        name:'vada' ,
        pic:'./img/vada.png',
        price:40,
        rating:3.4,
        description:'some some some some some content....'
    },
    {
        name:'paratha' ,
        pic:'./img/paratha.png',
        price:40,
        rating:3.4,
        description:'some some some some some content....'
    }
]

export default items