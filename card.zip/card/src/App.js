import React from "react";
import ItemsDisplay from "./components/ItemsDisplay";
function App() {
  return (
    <>
     <ItemsDisplay/>
    </>
  );
}

export default App;
